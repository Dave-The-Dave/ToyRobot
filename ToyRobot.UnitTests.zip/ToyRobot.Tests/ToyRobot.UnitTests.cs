using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Runtime.CompilerServices;
using ToyRobot.Models;

namespace ToyRobot.UnitTests
{
    [TestClass]
    public class ToyRobotUnitTests
    {
        [TestMethod]
        public void CanBePlaced()
        {
            var table = new Table(5);
            var robot = new Robot(table);

            robot.Place(1, 1, Direction.NORTH);

            Assert.IsTrue(robot.IsPlaced());
        }

        [TestMethod]
        public void CanMove()
        {
            var table = new Table(5);
            var robot = new Robot(table);

            robot.Place(1, 1, Direction.NORTH);
            robot.Move();
            var result = robot.Report();

            Assert.AreEqual(result, "1,2,NORTH");


        }

        [TestMethod]
        public void CanRotate()
        {
            var table = new Table(5);
            var robot = new Robot(table);

            robot.Place(1, 1, Direction.SOUTH);
            robot.Right();
            var result = robot.Report();

            Assert.AreEqual(result, "1,1,WEST");

        }

        [TestMethod]
        public void CanMoveMultipleTimes()
        {
            var table = new Table(5);
            var robot = new Robot(table);

            robot.Place(1, 2, Direction.EAST);
            robot.Move();
            robot.Move();
            robot.Left();
            robot.Move();
            var result = robot.Report();

            Assert.AreEqual(result, "3,3,NORTH");

        }


        [TestMethod]
        public void CantMoveOffTable()
        {
            var table = new Table(5);
            var robot = new Robot(table);

            robot.Place(0, 0, Direction.NORTH);
            robot.Left();
            robot.Move();
            var result = robot.Report();

            Assert.AreEqual(result, "0,0,WEST");


        }
    }
}